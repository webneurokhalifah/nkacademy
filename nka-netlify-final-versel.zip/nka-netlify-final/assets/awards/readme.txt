Letakkan logo sebenar di folder ini dan kekalkan nama fail yang sama:
- titanium.png
- malaysia-book-records.png
- british-publishing-house.png
- nka-10-years.png
- babytalk-awards.png
- anugerah-personaliti-2022.png
